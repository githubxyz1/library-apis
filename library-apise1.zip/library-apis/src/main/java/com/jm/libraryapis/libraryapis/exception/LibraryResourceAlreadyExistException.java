package com.jm.libraryapis.libraryapis.exception;

public class LibraryResourceAlreadyExistException extends Exception {
    public LibraryResourceAlreadyExistException(String message) {
        super(message);
    }
}
