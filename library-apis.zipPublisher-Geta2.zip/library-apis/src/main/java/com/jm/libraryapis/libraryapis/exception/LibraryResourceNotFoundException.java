package com.jm.libraryapis.libraryapis.exception;

public class LibraryResourceNotFoundException extends Exception {
    public LibraryResourceNotFoundException(String message) {
        super(message);
    }
}
