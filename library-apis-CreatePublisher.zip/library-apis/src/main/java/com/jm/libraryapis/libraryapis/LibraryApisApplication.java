package com.jm.libraryapis.libraryapis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibraryApisApplication {

    public static void main(String[] args) {
        SpringApplication.run(LibraryApisApplication.class, args);
    }

}
